<?php include('partials-front/menu.php');

?>


<section class="food-search">
    <div class="container">

        <h2 class="text-center text-white">Login Form</h2>

        <form action="" method="POST" class="order">


            <fieldset>
                <legend>fill the information</legend>
                <div class="order-label">Email</div>
                <input type="text" name="cus_email" placeholder="Enter Your Email" class="input-responsive" required>



                <div class="order-label">Password</div>
                <input type="password" name="cus_password" placeholder="Enter Your Password" class="input-responsive" required>




                <input type="submit" name="submit" value="LOGIN" class="btn btn-primary">


                <div class="signup-link">Not a member ? <a class="signup-link" href="<?php echo SITEURL; ?>signup.php">Signup</a></div>
            </fieldset>


        </form>

        <?php

        //CHeck whether submit button is clicked or not
        if (isset($_POST['submit'])) {

            //Process for Login
            //1. Get the Data from Login form

            $cus_email = mysqli_real_escape_string($conn, $_POST['cus_email']);

            $cus_password = md5($_POST['cus_password']);

            $password = mysqli_real_escape_string($conn, $cus_password);

            //2. SQL to check whether the user with username and password exists or not
            $sql = "SELECT * FROM `customer_info` WHERE `cus_email`='$cus_email' AND `cus_password`='$password'";


            //3. Execute Query 
            $res = mysqli_query($conn, $sql);

            //4. Count rows to check whether the user exists or not
            echo   $count = mysqli_num_rows($res);




            if ($count == 1) {
                //User AVailable and Login Success
                $_SESSION['user-login'] = "<div class='success'>Login Successful.</div>";
                $_SESSION['user-email'] = $cus_email; //TO check whether the user is logged in or not and logout will unset it

                //REdirect to HOme Page/Dashboard
                header('location:' . SITEURL . 'order.php/');
            } else {
                //User not Available and Login FAil
                $_SESSION['user-login'] = "<div class='error text-center'>Username or Password did not match.</div>";
                //REdirect to HOme Page/Dashboard
                header('location:' . SITEURL . 'login.php');
            }
        }

        ?>

    </div>
</section>

<?php include('partials-front/footer.php'); ?>