<?php include('partials-front/menu.php'); ?>

<section class="food-search">
    <div class="container">

        <h2 class="text-center text-white">Signup Form</h2>

        <form action="" method="POST" class="order">


            <fieldset>
                <legend>fill the information</legend>
                <div class="order-label">First Name</div>
                <input type="text" name="first_name" placeholder="First Name" class="input-responsive" required>

                <div class="order-label">Last Name</div>
                <input type="text" name="last_name" placeholder="Last Name" class="input-responsive" required>


                <div class="order-label">Email</div>
                <input type="email" name="cus_email" placeholder="Email" class="input-responsive" required>



                <div class="order-label">Password</div>
                <input type="password" name="cus_password" placeholder="Password" class="input-responsive" required>

                <div class="order-label">Confirm Password</div>
                <input type="password" name="email" placeholder="Confirm Password" class="input-responsive" required>






                <input type="submit" name="submit" value="Signup" class="btn btn-primary">


                <div class="signup-link">Already have an account ? <a class="signup-link" href="<?php echo SITEURL; ?>login.php">Login</a></div>
            </fieldset>


        </form>

        <?php

        //CHeck whether submit button is clicked or not
        if (isset($_POST['submit'])) {
            // Get all the details from the form


            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];
            $cus_email = $_POST['cus_email'];
            $cus_password = md5($_POST['cus_password']);


            //2.to check already user exist or not 
            $query1 = "SELECT * FROM `customer_info` WHERE `cus_email` = ' $cus_email'";

            // Execute query
            $result = mysqli_query($conn, $query1);

            // Check if any rows were returned
            if (mysqli_num_rows($result) > 0) {
                // User already exists

                $_SESSION['add'] = "<div class='error'>This Email already exists.</div>";
                header("location:" . SITEURL . 'admin/add-admin.php');
            } else {
                //Save the Order in Databaase
                //Create SQL to save the data
                $sql = "INSERT INTO `customer_info` SET first_name = '$first_name', last_name = '$last_name' , cus_email = '$cus_email', cus_password = '$cus_password'";

                //echo $sql2; die();

                //Execute the Query
                $res = mysqli_query($conn, $sql);

                //Check whether query executed successfully or not
                if ($res == true) {
                    //Query Executed and Order Saved
                    $_SESSION['signup'] = "<div class='success text-center'>User Signup Successfully.</div>";
                    header('location:' . SITEURL . 'login.php');
                } else {
                    //Failed to Save Order
                    $_SESSION['signup'] = "<div class='error text-center'>User Signup Successfully.</div>";
                    header('location:' . SITEURL . 'signup.php');
                }

            }

            
        }

        ?>

    </div>
</section>

<?php include('partials-front/footer.php'); ?>