
<?php include('partials-front/menu.php'); ?>

<section class="food-search">
        <div class="container">
            
            <h2 class="text-center text-white">Contact with us</h2>

            <form action="" method="POST" class="order">
                
                
                <fieldset>
                    <legend>fill the information</legend>
                    <div class="order-label">Full Name</div>
                    <input type="text" name="full-name" placeholder="Your Name" class="input-responsive" required>

                   

                    <div class="order-label">Email</div>
                    <input type="email" name="email" placeholder="example@email.com" class="input-responsive" required>

                    <div class="order-label">Message</div>
                    <textarea name="address" rows="10" placeholder="write your message" class="input-responsive" required></textarea>

                    <input type="submit" name="submit" value="SEND MESSAGE" class="btn btn-primary">
                </fieldset>

            </form>

            <?php 

                //CHeck whether submit button is clicked or not
                if(isset($_POST['submit']))
                {
                    // Get all the details from the form


                    $customer_name = $_POST['full-name'];
      
                    $customer_email = $_POST['email'];
                    $customer_address = $_POST['address'];


                    //Save the Order in Databaase
                    //Create SQL to save the data
                    $sql2 = "INSERT INTO `contact_us`  SET 
                       
                       user_name = '$customer_name',
                    
                       user_email = '$customer_email',
                       `address` = '$customer_address'
                    ";

                    //echo $sql2; die();

                    //Execute the Query
                    $res2 = mysqli_query($conn, $sql2);

                    //Check whether query executed successfully or not
                    if($res2==true)
                    {
                        //Query Executed and Order Saved
                        $_SESSION['order'] = "<div class='success text-center'>Message send Successfully.</div>";
                        header('location:'.SITEURL);
                    }
                    else
                    {
                        //Failed to Save Order
                        $_SESSION['order'] = "<div class='error text-center'>Failed to Message send .</div>";
                        header('location:'.SITEURL);
                    }

                }
            
            ?>

        </div>
    </section>

<?php include('partials-front/footer.php'); ?>