<?php

include('../config/constants.php');
include('login-check.php');

echo $username = $_SESSION['user'];



// echo $sql = "SELECT * FROM `tbl_admin` WHERE `username`=  $username";

// $res = mysqli_query($conn,$sql);

// echo $count = mysqli_num_rows($res);

// if ($count  == 1) {


?>


<html>

<head>
    <title>Food Order Website - Home Page</title>

    <link rel="stylesheet" href="../css/admin.css">
</head>

<body>
    <!-- Menu Section Starts -->
    <div class="menu text-center">
        <div class="wrapper">
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php
                if ($username == 'eh') {
                    ?>
                <li><a href="manage-admin.php">Admin</a></li>
                <?php
                }

                ?>
                
                <li><a href="manage-category.php">Category</a></li>
                <li><a href="manage-food.php">Food</a></li>
                <li><a href="manage-order.php">Manage Order</a></li>
                <li><a href="manage-ordered.php">Ordered</a></li>
                <li><a href="manage-all-on-delivery.php">On-Delivery</a></li>
                <li><a href="manage-all-delivered.php">Delivered</a></li>
                <li><a href="manage-all-cancelled.php">Cancelled</a></li>
                <li><a href="message.php">Message</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
    <!-- Menu Section Ends -->